package com.pcwk.ehr.domain;

public class MainVO {

}
