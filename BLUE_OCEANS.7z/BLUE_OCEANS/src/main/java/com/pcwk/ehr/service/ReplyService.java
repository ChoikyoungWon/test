package com.pcwk.ehr.service;
	
import com.pcwk.ehr.domain.BoardVO;
import com.pcwk.ehr.domain.ReplyVO;

import java.sql.SQLException;
import java.util.List;

import com.pcwk.ehr.cmn.WorkDiv;
	
public interface ReplyService extends WorkDiv<ReplyVO> {



	 


	
}
