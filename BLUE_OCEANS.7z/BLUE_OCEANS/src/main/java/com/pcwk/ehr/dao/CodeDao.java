package com.pcwk.ehr.dao;

import com.pcwk.ehr.cmn.PcwkLogger;
import com.pcwk.ehr.cmn.WorkDiv;
import com.pcwk.ehr.domain.CodeVO;

public interface CodeDao extends WorkDiv<CodeVO>, PcwkLogger {
	
	
	
	
	
	
	
	
	
}


